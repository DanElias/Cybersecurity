# Cryptography
CryptoSpyro is our brand new cryptographic algorithm
- Developed with HTML, JavaScript and Tailwind CSS
- Plain HTML, Javascript, CSS - to run just open the index.html
